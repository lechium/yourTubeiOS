//
//  AppDelegate.h
//  TestSearchApp
//
//  Created by Kevin Bradley on 2/2/16.
//  Copyright © 2016 nito. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KBYTDownloadsTableViewController.h"
#import "KBYTSearchTableViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

