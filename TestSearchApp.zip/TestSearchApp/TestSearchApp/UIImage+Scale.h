//
//  UIImage+UIImage_Scale.h
//  yourTubeiOS
//
//  Created by Kevin Bradley on 1/27/16.
//
//

#import <UIKit/UIKit.h>

@interface UIImage (Scale)

- (UIImage *)scaledImagedToSize:(CGSize)newSize;

@end
